# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

# TODO
1. Setting button pop-up
1.1. after click on "Setting button" we should get pop-up window where we can change:
    - difficult level (diemension of generated grid)
    - add new words
    - check scores (this might be another buttom)
2. After clicking "Undo" button, word on word-list should again be visieble