import './header.component.css'

function Header() {
    return(
        < header>
        < h1 className="title">Soup of Letters</h1>
        </header>)
}

export default Header;